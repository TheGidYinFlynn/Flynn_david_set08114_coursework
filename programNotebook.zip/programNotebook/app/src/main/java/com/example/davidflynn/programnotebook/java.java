package com.example.davidflynn.programnotebook;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;

public class java extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_java);



        Button save = (Button) findViewById(R.id.savajava);
        save.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                EditText edText1 = (EditText) findViewById(R.id.editTextjava);
                String filename = "SavedJava";
                String fileContents = edText1.getText().toString();
                Log.i("bitchin", fileContents);
                FileOutputStream outputStream;

                try {
                    outputStream = openFileOutput(filename, Context.MODE_PRIVATE);
                    outputStream.write(fileContents.getBytes());
                    outputStream.close();
                    Log.i("bitchin", "File was saved");
                } catch (Exception e) {
                    e.printStackTrace();
                    Log.i("bitchin", "File not saved");
                }
            }
        });

        Button load = (Button) findViewById(R.id.loadjava);
        load.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {

                String filename = "SavedJava";
                StringBuffer inString = new StringBuffer (" ");
                FileInputStream inStream ;

                try {
                    inStream = getApplicationContext().openFileInput(filename);

                    BufferedReader reader = new BufferedReader(new InputStreamReader(inStream));
                    StringBuilder sb = new StringBuilder();

                    String line = null;
                    try {
                        while ((line = reader.readLine()) != null) {
                            sb.append(line + "\n");
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    } finally {
                        try {
                            inStream.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                    String fileinput = sb.toString();


                    EditText edText2 = (EditText) findViewById(R.id.editTextjava);

                    edText2.setText(fileinput);


                }
                catch (IOException e){

                }

            }
        });




    }
}
