package com.example.davidflynn.programnotebook;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;

public class csharp extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_csharp);

        Button save = (Button) findViewById(R.id.savecsharp);
        save.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                EditText edText1 = (EditText) findViewById(R.id.editText2);
                String filename = "Savedcsharp";
                String fileContents = edText1.getText().toString();

                FileOutputStream outputStream;

                try {
                    outputStream = openFileOutput(filename, Context.MODE_PRIVATE);
                    outputStream.write(fileContents.getBytes());
                    outputStream.close();

                } catch (Exception e) {
                    e.printStackTrace();

                }
            }
        });

        Button load = (Button) findViewById(R.id.loadcsharp);
        load.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {

                String filename = "Savedcsharp";
                StringBuffer inString = new StringBuffer (" ");
                FileInputStream inStream ;

                try {
                    inStream = getApplicationContext().openFileInput(filename);

                    BufferedReader reader = new BufferedReader(new InputStreamReader(inStream));
                    StringBuilder sb = new StringBuilder();

                    String line = null;
                    try {
                        while ((line = reader.readLine()) != null) {
                            sb.append(line + "\n");
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    } finally {
                        try {
                            inStream.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                    String fileinput = sb.toString();


                    EditText edText2 = (EditText) findViewById(R.id.editText2);

                    edText2.setText(fileinput);


                }
                catch (IOException e){

                }

            }
        });
    }
}
